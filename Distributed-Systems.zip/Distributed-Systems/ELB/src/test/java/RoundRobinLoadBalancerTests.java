import error.MaxLoadException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import protocol.AppServer;
import protocol.LoadBalancer;

import java.text.MessageFormat;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

public class RoundRobinLoadBalancerTests {

    @Test
    public void testRoundRobinOneAppServer() {
        String customUuid = Constants.dummyAppServerName;
        AppServer appServer = Utils.createSimpleAppServer(customUuid);

        LoadBalancer loadBalancer = Utils.createRoundRobinLoadBalancer();
        loadBalancer.registerAppServers(List.of(appServer));

        System.out.println(MessageFormat.format(
                "Send {0} requests to the appServer. All of them must return the same UUID",
                Constants.appServerMaxConcurrentRequests));

        for (int i = 0; i < Constants.appServerMaxConcurrentRequests; i++) {
            assertEquals(customUuid, loadBalancer.get());
        }
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 5, 10, 64})
    public void testRoundRobinMultipleAppServers(Integer appServerCount) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        LoadBalancer loadBalancer = Utils.createRoundRobinLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createSimpleAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out
                .println("Check that requests to load balancer will be forwarded to all appServers");

        for (int i = 0; i < Constants.appServerMaxConcurrentRequests * appServerNames.size(); i++) {
            Integer appServerIdx = i % appServerNames.size();
            assertEquals(appServerNames.get(appServerIdx), loadBalancer.get());
        }

        System.out.println("The load on each appServer must be at its peak, since we invoked "
                + "the maximum allowed request for each appServer");

        for (AppServer appServer : appServers) {
            assertTrue(Math.abs(1.0 - appServer.getCurrentLoad()) < Constants.eps);
        }
    }

    @ParameterizedTest
    @CsvSource({"1,29", "3,33", "7,97", "10,123"})
    public void testRoundRobinMultipleAppServersOverloaded(Integer appServerCount, Integer requests) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        LoadBalancer loadBalancer = Utils.createRoundRobinLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createSimpleAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out.println("Check that load balancer will throw an exception once maximum "
                + "capacity is reached on all appServers");

        assertThrows(MaxLoadException.class, () -> {
            for (int i = 0; i < requests; i++) {
                loadBalancer.get();
            }
        });
    }
}
