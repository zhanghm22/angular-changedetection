package starter;

import appengine.BaseEngine;
import impl.BaseLoadBalancer;
import impl.RandomLoadBalancer;
import impl.RoundRobinLoadBalancer;
import impl.SimpleAppServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import propmodel.App;
import propmodel.Server;
import propmodel.ServerInfo;
import propmodel.Servers;
import protocol.AppServer;
import utils.UrlBean;

import java.io.InputStream;
import java.time.Duration;
import java.util.LinkedList;
import java.util.List;

@SpringBootApplication
@ComponentScan(basePackages = {"controllers", "starter", "utils"})
public class StartAPP {

    @Autowired
    UrlBean urlBean;
    @Value("${elb.rule}")
    private String rule;

    public static void main(String[] args) {
        SpringApplication.run(StartAPP.class, args);
    }

    @Bean
    public BaseLoadBalancer registerLB() throws Exception {
        if (rule == null)
            throw new Exception("LB rule is not defined");

        BaseLoadBalancer lb = null;
        if (rule.equals("random")) {
            lb = new RandomLoadBalancer(2000l, 1000l);
        } else if (rule.equals("round")) {
            lb = new RoundRobinLoadBalancer(2000l, 1000l);
        }

        if (lb == null)
            throw new Exception("LB rule is not properly defined");

        List<AppServer> appServers = new LinkedList<>();

        Yaml yaml = new Yaml(new Constructor(Servers.class));
        InputStream inputStream = this.getClass()
                .getClassLoader()
                .getResourceAsStream("servers.yml");
        Servers servers = yaml.load(inputStream);

        for (ServerInfo serverInfo : servers.getServers()) {
            Server server = serverInfo.getServer();

            AppServer appServer = new SimpleAppServer(1, Duration.ofSeconds(5), server.getId(), server.getPort());

            App app = serverInfo.getEngine().getApp();
            BaseEngine engine = (BaseEngine) Class.forName(app.getClazz()).getDeclaredConstructor().newInstance(new Object[]{});
            engine.setAppName(app.getName());
            String url = app.getUrl();
            url = url.substring(url.indexOf("/") + 1);
            engine.setURL(url);
            appServer.registerEngine(engine);
            engine.start();

            urlBean.addMapping(url, engine);

            appServers.add(appServer);
        }

        if (appServers.isEmpty())
            throw new Exception("Servers info is not properly defined");

        lb.registerAppServers(appServers);
        return lb;
    }
}
