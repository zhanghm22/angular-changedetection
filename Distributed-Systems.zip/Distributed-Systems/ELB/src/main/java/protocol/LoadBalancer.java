package protocol;

import error.AppServerAlreadyRegisteredException;
import error.AppServerNotFoundException;
import error.MaxLoadException;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface LoadBalancer {

    void registerAppServers(List<AppServer> appServers);

    void addAppServer(AppServer appServer) throws AppServerAlreadyRegisteredException;

    void removeAppServer(AppServer appServer) throws AppServerNotFoundException;

    String get() throws MaxLoadException;

    String routeToEAS(String url, HttpServletRequest request);
}
