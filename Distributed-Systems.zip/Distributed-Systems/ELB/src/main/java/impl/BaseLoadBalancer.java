package impl;

import error.AppServerAlreadyRegisteredException;
import error.AppServerNotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protocol.AppServer;
import protocol.LoadBalancer;

import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

public abstract class BaseLoadBalancer implements LoadBalancer {

    private static final Integer APPSERVER_UNAVAILABLE_RESET_PINGS = -2;

    private static Logger logger = LogManager.getLogger(BaseLoadBalancer.class);

    private final Executor aliveCheckExecutor;

    private final Timer appServerAliveTimer;

    private final Long aliveTimeout;

    protected List<AppServer> appServers;

    protected Map<AppServer, Integer> alivePings;

    protected BaseLoadBalancer(Long checkAliveInterval, Long aliveTimeout) {

        // Sanity check
        if (checkAliveInterval <= 0) {
            throw new IllegalArgumentException("Check alive interval must be greater than 0!");
        }
        if (checkAliveInterval <= 0) {
            throw new IllegalArgumentException(
                    "AppServer alive check timeout must be greater than 0!");
        }
        if (aliveTimeout >= checkAliveInterval) {
            throw new IllegalArgumentException(
                    "Check alive interval must be greater than appServer alive check timeout!");
        }

        appServers = Collections.synchronizedList(new ArrayList<>());
        alivePings = Collections.synchronizedMap(new HashMap<AppServer, Integer>());

        this.aliveTimeout = aliveTimeout;

        // Create the thread pool for alive appServer checks
        aliveCheckExecutor = Executors.newCachedThreadPool();

        // Create a timer that will check from time to time if the appServers are alive
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                logger.debug("Time {} fired!", appServerAliveTimer);
                timerFired();
            }
        };

        appServerAliveTimer =
                new Timer(MessageFormat.format("appServer_alive_timer_{0}", UUID.randomUUID()));
        appServerAliveTimer.scheduleAtFixedRate(timerTask, checkAliveInterval, checkAliveInterval);
    }

    public void registerAppServers(List<AppServer> appServers) {

        // Replace existing appServers
        this.appServers = Collections.synchronizedList(new ArrayList<>(appServers));
        this.alivePings = Collections.synchronizedMap(new HashMap<>(
                appServers.stream().collect(Collectors.toMap(Function.identity(), appServer -> 0))));
    }

    public void addAppServer(AppServer appServer) throws AppServerAlreadyRegisteredException {

        // Sanity check
        if (alivePings.containsKey(appServer)) {
            throw new AppServerAlreadyRegisteredException(
                    MessageFormat.format("AppServer {0} already registered!", appServer));
        }

        appServers.add(appServer);
        alivePings.put(appServer, 0);
    }

    public void removeAppServer(AppServer appServer) throws AppServerNotFoundException {

        // Sanity check
        if (!alivePings.containsKey(appServer)) {
            throw new AppServerNotFoundException(MessageFormat
                    .format("AppServer {0} not registered on this Load Balancer!", appServer));
        }

        appServers.remove(appServer);
        alivePings.remove(appServer);
    }

    private void timerFired() {

        // Check if the appServer is alive in a dedicated thread (one thread per appServer)
        for (AppServer appServer : alivePings.keySet()) {

            // @formatter:off
            CompletableFuture.supplyAsync(appServer::check, aliveCheckExecutor)
                    .orTimeout(aliveTimeout, TimeUnit.MILLISECONDS)
                    .whenCompleteAsync((result, e) -> updateAlivePings(appServer, result, e));
            // @formatter:on
        }
    }

    private void updateAlivePings(AppServer appServer, Boolean result, Throwable exception) {

        if (exception != null || !result) {

            // Reset the number of pings
            alivePings.put(appServer, APPSERVER_UNAVAILABLE_RESET_PINGS);

            String errorMessage = exception != null ? exception.getClass().getSimpleName() : "null";
            logger.error("AppServer {} not responding! Marking it as not alive! Exception: {}",
                    appServer, errorMessage);
        } else {

            // Increment the count of subsequent successful pings
            Integer currentPingCount = alivePings.get(appServer);
            alivePings.put(appServer, currentPingCount + 1);

            logger.debug("AppServer {} still alive!", appServer);
        }
    }
}
