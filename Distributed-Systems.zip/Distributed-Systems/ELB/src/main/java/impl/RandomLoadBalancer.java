package impl;

import error.AppServerNotFoundException;
import error.MaxLoadException;
import protocol.AppServer;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

public class RandomLoadBalancer extends BaseLoadBalancer {

    private Random random = new Random();

    public RandomLoadBalancer(Long checkAliveInterval, Long aliveTimeout) {
        super(checkAliveInterval, aliveTimeout);
    }

    private AppServer getServer() {
        return getServer(null);
    }

    private AppServer getServer(String url) {

        // Sanity check
        if (appServers.isEmpty()) {
            throw new AppServerNotFoundException("Load Balancer has no registered appServers!");
        }

        // Filter out dead/unresponsive appServers or the appServers that are overloaded
        List<AppServer> aliveAppServers = alivePings.entrySet().stream()
                .filter(entry -> url != null && entry.getKey().getUrl().equals(url))
                .filter(entry -> entry.getValue() >= 0 && entry.getKey().getCurrentLoad() < 1.0)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Check if there are alive app servers
        if (aliveAppServers.isEmpty()) {
            throw new MaxLoadException("All appServers are down or overloaded!");
        }


        return aliveAppServers.get(random.nextInt(aliveAppServers.size()));
    }

    @Override
    public String routeToEAS(String url, HttpServletRequest request) {
        return getServer(url).callEngine(request);
    }

    @Override
    public String get() throws MaxLoadException {

        return getServer().get();
    }
}
