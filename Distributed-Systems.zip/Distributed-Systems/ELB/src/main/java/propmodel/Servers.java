package propmodel;

import java.util.List;

public class Servers {

    private List<ServerInfo> servers;

    public List<ServerInfo> getServers() {
        return servers;
    }

    public void setServers(List<ServerInfo> serverInfos) {
        this.servers = serverInfos;
    }
}
