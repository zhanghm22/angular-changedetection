package controllers;

import error.AppServerNotFoundException;
import impl.BaseLoadBalancer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import utils.UrlBean;

import javax.servlet.http.HttpServletRequest;


@RestController
public class HomeController {

    @Autowired
    BaseLoadBalancer baseLoadBalancer;
    @Autowired
    UrlBean urlBean;

    @GetMapping("/{url}")
    public String home(@PathVariable String url, HttpServletRequest request) {
        if (urlBean.searchForMapping(url) == null)
            throw new AppServerNotFoundException("Cannot find corresponding engine for" + url);
        return baseLoadBalancer.routeToEAS(url, request);
    }
}
