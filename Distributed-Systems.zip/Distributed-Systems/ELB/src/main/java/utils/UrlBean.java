package utils;

import org.springframework.stereotype.Component;
import protocol.AppEngine;

import java.util.concurrent.ConcurrentHashMap;

@Component
public class UrlBean {
    ConcurrentHashMap<String, AppEngine> url2Engine = new ConcurrentHashMap<>();

    public void addMapping(String url, AppEngine engine) {
        url2Engine.put(url, engine);
    }

    public AppEngine searchForMapping(String url) {
        return url2Engine.get(url);
    }
}
