package error;

public class AppServerAlreadyRegisteredException extends RuntimeException {

    public AppServerAlreadyRegisteredException(String message) {
        super(message);
    }

    public AppServerAlreadyRegisteredException(String message, Exception exception) {
        super(message, exception);
    }
}
