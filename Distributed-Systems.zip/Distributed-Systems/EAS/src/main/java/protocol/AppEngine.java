package protocol;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.SynchronousQueue;

public interface AppEngine {

    void setInQue(SynchronousQueue<HttpServletRequest> reqQue);

    void setOutQue(SynchronousQueue<String> resQue);

    void setServerId(String id);

    void setAppName(String name);

    String getURL();

    void setURL(String url);
}
