package protocol;

import javax.servlet.http.HttpServletRequest;

public interface AppServer {

    String get();

    Boolean check();

    Float getCurrentLoad();

    void setAvailability(Boolean availability);

    void registerEngine(AppEngine engine);

    String callEngine(HttpServletRequest request);

    String getUrl();
}
