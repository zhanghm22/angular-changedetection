package appengine;

import javax.servlet.http.HttpServletRequest;

public class SimpleEngine2 extends BaseEngine {
    public void run() {
        HttpServletRequest request = null;
        try {
            while (true) {
                request = reqQue.take();
                //Perhaps we'll do something to request in future
                request.getDispatcherType();
                resQue.put("Welcome to server " + serverId + ". -- from Engine 2, url=" + url);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
