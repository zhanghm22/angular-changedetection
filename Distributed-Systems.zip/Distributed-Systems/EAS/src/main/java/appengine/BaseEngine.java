package appengine;

import protocol.AppEngine;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.SynchronousQueue;

public abstract class BaseEngine extends Thread implements AppEngine {
    protected SynchronousQueue<HttpServletRequest> reqQue;
    protected SynchronousQueue<String> resQue;
    protected String serverId;
    protected String appName;
    protected String url;

    @Override
    public void setInQue(SynchronousQueue<HttpServletRequest> reqQue) {
        this.reqQue = reqQue;
    }

    @Override
    public void setOutQue(SynchronousQueue<String> resQue) {
        this.resQue = resQue;
    }

    @Override
    public void setServerId(String id) {
        this.serverId = id;
    }

    @Override
    public void setAppName(String name) {
        this.appName = name;
    }

    @Override
    public String getURL() {
        return url;
    }

    @Override
    public void setURL(String url) {
        this.url = url;
    }
}
