package impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import protocol.AppEngine;
import protocol.AppServer;

import javax.servlet.http.HttpServletRequest;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.Semaphore;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleAppServer implements AppServer {

    private static Logger logger = LogManager.getLogger(SimpleAppServer.class);

    private final Integer maxConcurrentRequests;

    private final Duration oneRequestProcessingTime;

    private final String uuid;

    private AtomicInteger currentRequests = new AtomicInteger();

    private Lock availabilityLock = new ReentrantLock();

    private Semaphore semaphore;

    private String id;

    private Integer port;

    private AppEngine engine;

    private String url;

    private SynchronousQueue<HttpServletRequest> reqQue = new SynchronousQueue();

    private SynchronousQueue<String> resQue = new SynchronousQueue();


    public SimpleAppServer(Integer maxConcurrentRequests, Duration oneRequestProcessingTime, String id, Integer port) {
        this(UUID.randomUUID().toString(), maxConcurrentRequests, oneRequestProcessingTime, id, port);
    }

    public SimpleAppServer(String customUuid, Integer maxConcurrentRequests,
                           Duration oneRequestProcessingTime, String id, Integer port) {
        // Sanity check
        if (Strings.isEmpty(customUuid)) {
            throw new IllegalArgumentException("UUID cannot be `null` or empty!");
        }
        if (maxConcurrentRequests <= 0) {
            throw new IllegalArgumentException(
                    "Maximum allowed concurrent requests must be greater than zero!");
        }
        if (oneRequestProcessingTime.isNegative()) {
            throw new IllegalArgumentException("Processing time for one request must be positive!");
        }

        this.uuid = customUuid;
        this.maxConcurrentRequests = maxConcurrentRequests;
        this.oneRequestProcessingTime = oneRequestProcessingTime;
        this.semaphore = new Semaphore(maxConcurrentRequests);
        this.id = id;
        this.port = port;
    }

    @Override
    public String get() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        currentRequests.incrementAndGet();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                semaphore.release();
                currentRequests.decrementAndGet();
            }
        };
        Timer timer = new Timer(MessageFormat.format("timer_{0}", UUID.randomUUID()));
        timer.schedule(task, oneRequestProcessingTime.toMillis());

        availabilityLock.unlock();
        return uuid;
    }

    @Override
    public Boolean check() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        semaphore.release();
        availabilityLock.unlock();

        return true;
    }

    @Override
    public Float getCurrentLoad() {
        return (float) currentRequests.get() / (float) maxConcurrentRequests;
    }

    @Override
    public void setAvailability(Boolean availability) {

        if (Boolean.FALSE.equals(availability)) {
            if (!availabilityLock.tryLock()) {
                logger.warn("Availability already set to `true`.");
            }
        } else {
            availabilityLock.unlock();
        }
    }

    @Override
    public void registerEngine(AppEngine engine) {
        engine.setInQue(reqQue);
        engine.setOutQue(resQue);
        engine.setServerId(id);
        this.engine = engine;
        this.url = engine.getURL();
    }

    @Override
    public String callEngine(HttpServletRequest request) {
        String res = "No response from App";
        try {
            reqQue.put(request);
            res = resQue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return res;

    }

    @Override
    public String getUrl() {
        return url;
    }

}
