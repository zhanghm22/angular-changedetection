mvn clean install -Dmaven.test.skip
cd elb
mvn clean spring-boot:run
