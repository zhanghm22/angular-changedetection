package impl;

import protocol.MockRequest;

public class SimpleMockRequest implements MockRequest {
    @Override
    public void mockAction() {

    }
}
