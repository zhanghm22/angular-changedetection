package impl;

import protocol.AppServer;
import protocol.ServerContainer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

public abstract class BaseServerContainer implements ServerContainer {

    protected List<AppServer> serverList = Collections.synchronizedList(new ArrayList<>());
    Logger logger = java.util.logging.Logger.getGlobal();

    @Override
    public abstract void syncServersWithELB() throws InterruptedException;

    @Override
    public List<AppServer> getServerList() {
        return serverList;
    }

    @Override
    public abstract void setServerList(List<AppServer> serverList);

    @Override
    public void registerServer(AppServer server) {
        serverList.add(server);
    }

    @Override
    public AppServer getServerByServerID(String serverID) {
        return serverList.stream().filter(server -> server.getServerId().equals(serverID)).findFirst().get();
    }

    @Override
    public AppServer getServerByUUID(String uuid) {
        return serverList.stream().filter(server -> server.getUUID().equals(uuid)).findFirst().get();
    }

    @Override
    public void shutdownServer(String serverID) throws InterruptedException {
        serverList.stream().filter(server -> server.getServerId().equals(serverID)).findFirst().ifPresent(server -> {
            server.makeServerDown();
            serverList.remove(server);
        });
        logger.info(serverID + "is removed");
    }
}
