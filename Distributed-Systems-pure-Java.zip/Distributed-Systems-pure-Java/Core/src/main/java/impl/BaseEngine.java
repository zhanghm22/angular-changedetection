package impl;

import protocol.AppEngine;
import protocol.AppServer;
import protocol.MockRequest;
import protocol.Processor;

import java.util.UUID;
import java.util.concurrent.SynchronousQueue;

public abstract class BaseEngine implements AppEngine {

    protected String instanceID;
    protected AppServer server;
    protected SynchronousQueue<MockRequest> reqQue;
    protected SynchronousQueue<String> resQue;
    protected String appName;
    protected String url;
    protected Processor processor;


    public BaseEngine(AppServer server, String appName, String url) {
        this(UUID.randomUUID().toString(), server, appName, url);
    }

    public BaseEngine(String instanceID, AppServer server, String appName, String url) {
        this.instanceID = instanceID;
        this.server = server;
        this.reqQue = reqQue;
        this.resQue = resQue;
        this.appName = appName;
        this.url = url;
    }

    public String getInstanceID() {
        return instanceID;
    }

    public void setInstanceID(String instanceID) {
        this.instanceID = instanceID;
    }

    public AppServer getServer() {
        return server;
    }

    public void setServer(AppServer server) {
        this.server = server;
    }

    public SynchronousQueue<MockRequest> getReqQue() {
        return reqQue;
    }

    public void setReqQue(SynchronousQueue<MockRequest> reqQue) {
        this.reqQue = reqQue;
    }

    public SynchronousQueue<String> getResQue() {
        return resQue;
    }

    public void setResQue(SynchronousQueue<String> resQue) {
        this.resQue = resQue;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public Processor getProcessor() {
        return processor;
    }

    @Override
    public void setProcessor(Processor processor) {
        this.processor = processor;
    }

}
