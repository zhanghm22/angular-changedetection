package impl;

import org.apache.logging.log4j.util.Strings;
import protocol.AppEngine;
import protocol.AppServer;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class BaseAppServer implements AppServer {

    protected final Integer maxConcurrentRequests;

    protected final Duration oneRequestProcessingTime;

    protected final String uuid;

    protected AtomicInteger currentRequests = new AtomicInteger();

    protected Lock availabilityLock = new ReentrantLock();

    protected Semaphore semaphore;

    protected String serverId;

    protected Integer port;

    protected List<AppEngine> engines = Collections.synchronizedList(new ArrayList<>());

    protected Map<String, AppEngine> url2engine = new ConcurrentHashMap<>();

    protected List<String> urls = Collections.synchronizedList(new ArrayList<>());

    public BaseAppServer(Integer maxConcurrentRequests, Duration oneRequestProcessingTime, String id, Integer port) {
        this(UUID.randomUUID().toString(), maxConcurrentRequests, oneRequestProcessingTime, id, port);
    }

    public BaseAppServer(String customUuid, Integer maxConcurrentRequests,
                         Duration oneRequestProcessingTime, String id, Integer port) {
        // Sanity check
        if (Strings.isEmpty(customUuid)) {
            throw new IllegalArgumentException("UUID cannot be `null` or empty!");
        }
        if (maxConcurrentRequests <= 0) {
            throw new IllegalArgumentException(
                    "Maximum allowed concurrent requests must be greater than zero!");
        }
        if (oneRequestProcessingTime.isNegative()) {
            throw new IllegalArgumentException("Processing time for one request must be positive!");
        }

        this.uuid = customUuid;
        this.maxConcurrentRequests = maxConcurrentRequests;
        this.oneRequestProcessingTime = oneRequestProcessingTime;
        this.semaphore = new Semaphore(maxConcurrentRequests);
        this.serverId = id;
        this.port = port;
    }

    @Override
    public String getServerId() {
        return serverId;
    }

    @Override
    public Integer getPort() {
        return port;
    }

    @Override
    public List<String> getUrls() {
        return urls;
    }

    @Override
    public void makeServerDown() {

        if (!engines.isEmpty())
            engines.forEach(engine -> engine.destroy());
    }

    @Override
    public String getUUID() {
        return uuid;
    }
}
