package protocol;

public interface Processor {

    String process(String serverId, String url);
}
