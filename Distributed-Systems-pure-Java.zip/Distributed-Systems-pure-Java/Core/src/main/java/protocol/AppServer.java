package protocol;

import java.util.List;

public interface AppServer {

    String get();

    Boolean check();

    Float getCurrentLoad();

    void setAvailability(Boolean availability);

    void registerEngine(AppEngine engine);

    String callEngine(String url, MockRequest request);

    List<String> getUrls();

    String getServerId();

    Integer getPort();

    void makeServerDown();

    String getUUID();
}
