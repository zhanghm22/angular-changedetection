package protocol;

import java.util.List;

public interface ServerContainer {

    void syncServersWithELB() throws InterruptedException;

    List<AppServer> getServerList();

    void setServerList(List<AppServer> serverList);

    void registerServer(AppServer server);

    AppServer getServerByServerID(String serverID);

    AppServer getServerByUUID(String uuid);

    void shutdownServer(String serverID) throws InterruptedException;
}
