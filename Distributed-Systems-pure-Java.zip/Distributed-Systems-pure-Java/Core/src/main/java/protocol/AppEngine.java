package protocol;

public interface AppEngine {

    void init();

    String service();

    void destroy();

    String getInstanceID();

    void setInstanceID(String instanceID);

    AppServer getServer();

    void setServer(AppServer server);

    String getAppName();

    void setAppName(String appName);

    String getUrl();

    void setUrl(String url);

    Processor getProcessor();

    void setProcessor(Processor processor);
}
