package protocol;

public interface MockRequest {

    void mockAction();
}
