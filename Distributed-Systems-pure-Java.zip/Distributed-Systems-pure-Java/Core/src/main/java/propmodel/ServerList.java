package propmodel;

import java.util.List;

public class ServerList {

    private List<ServerInfo> servers;

    public List<ServerInfo> getServers() {
        return servers;
    }

    public void setServers(List<ServerInfo> serverInfos) {
        this.servers = serverInfos;
    }
}
