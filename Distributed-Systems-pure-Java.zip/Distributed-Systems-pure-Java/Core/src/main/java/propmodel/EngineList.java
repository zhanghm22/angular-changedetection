package propmodel;

import java.util.List;

public class EngineList {

    private List<Engineinfo> engines;

    public List<Engineinfo> getEngines() {
        return engines;
    }

    public void setEngines(List<Engineinfo> engines) {
        this.engines = engines;
    }
}
