package utils;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.InputStream;

public class YamlHelper {

    public static <T extends Object> T readConfiguration(String path, Class<T> type, Object obj) {
        Yaml yaml = new Yaml(new Constructor(type));
        InputStream inputStream = obj.getClass()
                .getClassLoader()
                .getResourceAsStream(path);
        return yaml.load(inputStream);
    }
}
