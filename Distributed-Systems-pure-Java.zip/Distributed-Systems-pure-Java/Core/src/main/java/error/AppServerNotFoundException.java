package error;

public class AppServerNotFoundException extends RuntimeException {

    public AppServerNotFoundException(String message) {
        super(message);
    }

    public AppServerNotFoundException(String message, Exception exception) {
        super(message, exception);
    }
}
