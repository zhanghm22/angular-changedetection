mvn clean install -Dmaven.test.skip
touch ~/eas-elb-data-interaction-file
chmod 777 ~/eas-elb-data-interaction-file
cd composer
mvn exec:java -Dexec.mainClass="starter.ComposeAllAndShow"
