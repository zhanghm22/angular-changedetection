# Citi Programming test - Distributed Systems Simulation

![image info](pics/citi%20test%201.png)
![image info](pics/citi%20test%202.png)
![image info](pics/citi%20test%203.png)

## Requirements

For building and running the application you need:

- JDK 11
- [Maven 3](https://maven.apache.org)

## Running the application locally

```shell
1. ./start.sh
or
2. In IDEA, execute Maven lifecycle goals "Distributed Systems Simulation -> clean -> install", and finally run ComposeAllAndShow.java
```

## Project Structure

1. **composer** - the module to startup apps, and compose a demo. All is inside ComposeAllAndShow.java
2. **Core** - contains bones of the project includes all interfaces/abstract/model stuff for structural purpose
3. **EAS** - module to implement a runnable EAS app, but now as we're leaning on demonstrating concepts rather than
   actual usage, the module has not been enabled to be started up individually. Instead, composer module integrates
   this.
4. **ELB** -quite like what I do for EAS, but as the entry to systems this would be the most critical component in
   ELB-EAS-Engine architect. Please have a look into composer to see how the module is on first place to be started up,
   and listening on EAS to register themselves.
5. **Engine** - the AppEngine. And we define Processor class for the Engine which means the Engine is able to execute
   any logic we write into Processor following the pattern.

## Some places in code need attention:

* **src/main/resources/eas-elb-data-interaction-file** - This file is used for communication between ELB and EAS, say an
  EAS want to register itself to ELB then it will write data to the file to let ELB know and do register.
* **src/main/java/EAScontainer/SimpleEASContainer.java** - Actually I want to fully decouple EAS and ELB, and I believe
  it's feasible, so I create the container entity to represent EAS, and try to let it to be the only entry to interact
  with ELB. But as this project is not a formal production one, so still left some unfinished.
* **src/main/java/customized/CustomizedLoadBalancer.java** - We can use our customized implementation of LoadBalancer.
  And I've intended to implement Best Available in this sample class, however I got more and more confused after read
  subject times...even I know the scoring and serverStatus things as the key for implementation and thoughts on how to
  implement.
* **xxx-configure.yml** All configuration things are done in the yaml for each of ELB, EAS and Engine. The content
  should be clear and concise for most developers I suppose. Just follow the patterns there.
* **To shutdown server(s)** - Still I've intended to make all things Hot deployed and loaded, but unfinished as it's not
  a prioritized goal for this test I suppose. So for example, to make server(s) shutdown and deregistered from ELB, we
  can change serverStatus in eas-elb-data-interaction-file on runtime, and it's hot-loaded. Like this:
  ![image info](pics/Screen%20Shot%202022-10-26%20at%2022.15.46.png)

* **CustomizedProcessor** - Engine is a shell, the actual logic we care about happens in Processor. It's defined in
  engines-configure.yml for which actual Processor to be used.


