package EAScontainer;

import impl.BaseServerContainer;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import propmodel.ServerList;
import protocol.AppServer;
import utils.YamlHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.logging.Logger;

import static java.lang.Thread.sleep;

public class SimpleEASContainer extends BaseServerContainer {

    private static Logger logger = Logger.getGlobal();

    Path dataFile = Paths.get(this.getClass().getClassLoader().getResource("eas-elb-data-interaction-file").getFile());
    String configureFile = "eas-configure.yml";

    public void setConfigureFile(String file) {
        this.configureFile = file;
    }

    @Override
    public void syncServersWithELB() throws InterruptedException {

        ServerList servers = YamlHelper.readConfiguration(configureFile, ServerList.class, this);

        try {
            validateServers(servers);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        try {
            RandomAccessFile file = new RandomAccessFile(dataFile.toFile(), "rw");
            FileChannel channel = file.getChannel();
            FileLock lock = null;
            while (lock == null) {
                lock = channel.tryLock();
            }
            try {
                new Yaml(new Constructor(ServerList.class)).dump(servers, Channels.newWriter(channel, "UTF-8"));
            } finally {
                lock.release();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            logger.warning("change datafile location to System.getProperty(\"user.home\")+\"/eas-elb-data-interaction-file\"");
            dataFile = new File(System.getProperty("user.home") + "/eas-elb-data-interaction-file").toPath();
            syncServersWithELB();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (OverlappingFileLockException e) {
            sleep(1000l);
            syncServersWithELB();
        }

    }

    @Override
    public void setServerList(List<AppServer> serverList) {
        this.serverList = serverList;
    }

    private void validateServers(ServerList servers) throws Exception {

        if (servers.getServers().stream().anyMatch(serverInfo -> {
            serverInfo.getServer();
            /*do some validation here*/
            boolean anyproblem = false;
            return anyproblem;
        }))
            throw new Exception("validation failed");
    }
}
