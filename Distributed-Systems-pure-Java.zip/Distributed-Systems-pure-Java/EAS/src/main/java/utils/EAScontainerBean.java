package utils;

import protocol.ServerContainer;

public class EAScontainerBean {

    volatile private static EAScontainerBean instance = null;
    private ServerContainer container;

    private EAScontainerBean() {
    }

    public static EAScontainerBean getInstance() {

        if (instance != null) {

        } else {
            synchronized (EAScontainerBean.class) {
                if (instance == null) {
                    instance = new EAScontainerBean();
                }
            }
        }
        return instance;
    }

    public ServerContainer getContainer() {
        return container;
    }

    public synchronized void setContainer(ServerContainer container) {
        if (this.container != null)
            return;
        this.container = container;
    }
}
