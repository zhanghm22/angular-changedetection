package starter;

import EAScontainer.SimpleEASContainer;
import utils.EAScontainerBean;

public class StartEAS {

    EAScontainerBean containerBean = EAScontainerBean.getInstance();

    public void start(String configureFile) throws InterruptedException {

        synchronized (StartEAS.class) {
            if (containerBean.getContainer() == null) {
                containerBean.setContainer(new SimpleEASContainer());
            }

            SimpleEASContainer container = (SimpleEASContainer) containerBean.getContainer();
            container.setConfigureFile(configureFile);
            container.syncServersWithELB();
        }
    }
}
