package servers;

import impl.BaseAppServer;
import protocol.AppEngine;
import protocol.MockRequest;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.logging.Logger;

public class SimpleAppServer extends BaseAppServer {

    private static Logger logger = Logger.getGlobal();

    public SimpleAppServer(String id, int port) {
        super(1, Duration.ofSeconds(5), id, port);
    }

    public SimpleAppServer(Integer maxConcurrentRequests, Duration oneRequestProcessingTime, String id, Integer port) {
        super(maxConcurrentRequests, oneRequestProcessingTime, id, port);
    }

    public SimpleAppServer(String customUuid, Integer maxConcurrentRequests, Duration oneRequestProcessingTime, String id, Integer port) {
        super(customUuid, maxConcurrentRequests, oneRequestProcessingTime, id, port);
    }


    @Override
    public String get() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        currentRequests.incrementAndGet();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                semaphore.release();
                currentRequests.decrementAndGet();
            }
        };
        Timer timer = new Timer(MessageFormat.format("timer_{0}", UUID.randomUUID()));
        timer.schedule(task, oneRequestProcessingTime.toMillis());

        availabilityLock.unlock();
        return uuid;
    }

    @Override
    public Boolean check() {

        availabilityLock.lock();
        semaphore.acquireUninterruptibly();
        semaphore.release();
        availabilityLock.unlock();

        return true;
    }

    @Override
    public Float getCurrentLoad() {
        return (float) currentRequests.get() / (float) maxConcurrentRequests;
    }

    @Override
    public void setAvailability(Boolean availability) {

        if (Boolean.FALSE.equals(availability)) {
            if (!availabilityLock.tryLock()) {
                logger.warning("Availability already set to `true`.");
            }
        } else {
            availabilityLock.unlock();
        }
    }

    @Override
    public void registerEngine(AppEngine engine) {
        engines.add(engine);
        String url = engine.getUrl();
        if (urls.contains(url)) {
            AppEngine ori = url2engine.put(url, engine);
            engines.remove(ori);
        } else {
            urls.add(url);
            url2engine.put(url, engine);
        }
        engine.init();
    }

    @Override
    public String callEngine(String url, MockRequest request) {
        AppEngine engine = url2engine.get(url);

        return engine.service();

    }

}
