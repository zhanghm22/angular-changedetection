package processors;

import protocol.Processor;

public class CustomizedProcessor implements Processor {
    @Override
    public String process(String serverId, String url) {
        return "customized msg -- Welcome to " + serverId + " | " + url + " | ";
    }
}
