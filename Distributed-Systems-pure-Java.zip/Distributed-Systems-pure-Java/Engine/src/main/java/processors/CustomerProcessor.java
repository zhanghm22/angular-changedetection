package processors;

import protocol.Processor;

public class CustomerProcessor implements Processor {
    @Override
    public String process(String serverId, String url) {
        return "Welcome to " + serverId + " | " + url + " | ";
    }
}
