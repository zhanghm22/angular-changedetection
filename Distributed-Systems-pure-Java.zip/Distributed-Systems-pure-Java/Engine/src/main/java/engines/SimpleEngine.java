package engines;

import impl.BaseEngine;
import protocol.AppServer;

public class SimpleEngine extends BaseEngine {


    public SimpleEngine(AppServer server, String appName, String url) {
        super(server, appName, url);
    }

    public SimpleEngine(String instanceID, AppServer server, String appName, String url) {
        super(instanceID, server, appName, url);
    }

    @Override
    public void init() {

    }

    @Override
    public String service() {
        return processor.process(server.getServerId(), url);
    }

    @Override
    public void destroy() {

    }
}
