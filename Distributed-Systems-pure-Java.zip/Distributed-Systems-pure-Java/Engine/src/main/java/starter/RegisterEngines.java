package starter;

import engines.SimpleEngine;
import propmodel.App;
import propmodel.EngineList;
import propmodel.Engineinfo;
import protocol.AppEngine;
import protocol.AppServer;
import protocol.Processor;
import protocol.ServerContainer;
import utils.EAScontainerBean;
import utils.YamlHelper;

import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegisterEngines {

    public static Logger logger = Logger.getGlobal();

    public void registerEngine() {
        EngineList engineList = YamlHelper.readConfiguration("engines-configure.yml", EngineList.class, this);

        ServerContainer container = EAScontainerBean.getInstance().getContainer();
        List<AppServer> serverList = container.getServerList();

        for (Engineinfo engineinfo : engineList.getEngines()) {
            String serverId = engineinfo.getServer().getId();
            int port = engineinfo.getServer().getPort();

            App app = engineinfo.getEngine().getApp();
            String name = app.getName();
            String url = app.getUrl();
            String clazz = app.getClazz();

            if (serverList.stream().noneMatch(server -> server.getServerId().equals(serverId) && server.getPort() == port)) {
                logger.log(Level.WARNING, "Incorrect server specs or no existing registered server for: AppName - " + name + ", " + url + ", " + clazz);
                continue;
            }
            if (serverList.stream().anyMatch(server -> server.getUrls().contains(url))) {
                logger.log(Level.WARNING, "URL is already registered, will do update with: AppName - " + name + ", " + url + ", " + clazz);
            }

            AppServer server = serverList.stream().filter(server1 -> server1.getServerId().equals(serverId)).findFirst().get();
            AppEngine engine = new SimpleEngine(UUID.randomUUID().toString(), server, name, url);

            engine.init();
            try {
                engine.setProcessor((Processor) Class.forName(clazz).getConstructor().newInstance(new Object[]{}));
            } catch (Exception e) {
                logger.log(Level.WARNING, "Processor creation with problem for " + clazz);
                e.printStackTrace();
                continue;
            }

            server.registerEngine(engine);
        }
    }
}
