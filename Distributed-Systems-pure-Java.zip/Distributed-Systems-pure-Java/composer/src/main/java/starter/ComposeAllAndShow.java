package starter;


import impl.SimpleMockRequest;
import utils.LBbean;

import java.util.logging.Logger;

import static java.lang.Thread.sleep;


public class ComposeAllAndShow {

    public static void main(String... args) throws Exception {
        Logger logger = java.util.logging.Logger.getGlobal();

        LBbean lBbean = new StartELB().start();

        logger.info(lBbean.getLB().getClass().getTypeName());

        StartEAS easStarter = new StartEAS();

        easStarter.start("eas-configure.yml");

        sleep(10000l);
        new RegisterEngines().registerEngine();
        new Thread(() -> {
            try {
                while (true) {
                    sleep(10000l);
                    for (int i = 0; i < 20; i++) {
                        System.out.println(lBbean.getLB().routeToEAS("/customer", new SimpleMockRequest()));
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
        new Thread(() -> {
            try {
                while (true) {
                    sleep(10000l);
                    for (int i = 0; i < 20; i++) {
                        System.out.println(lBbean.getLB().routeToEAS("/customer2", new SimpleMockRequest()));
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
