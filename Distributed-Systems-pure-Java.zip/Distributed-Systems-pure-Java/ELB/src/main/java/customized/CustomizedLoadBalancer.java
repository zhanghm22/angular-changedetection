package customized;

import error.MaxLoadException;
import impl.BaseLoadBalancer;
import protocol.MockRequest;

import java.util.Random;

public class CustomizedLoadBalancer extends BaseLoadBalancer {

    public CustomizedLoadBalancer(Long checkAliveInterval, Long aliveTimeout) {
        super(checkAliveInterval, aliveTimeout);
    }

    @Override
    public String get() throws MaxLoadException {
        return appServers.get(new Random().ints(0, appServers.size()).findFirst().getAsInt()).get();
    }

    @Override
    public String routeToEAS(String url, MockRequest request) {
        return "A customized LB";
    }
}
