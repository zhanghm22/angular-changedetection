package balancers;

import error.AppServerNotFoundException;
import error.MaxLoadException;
import impl.BaseLoadBalancer;
import protocol.AppServer;
import protocol.MockRequest;

import java.util.List;
import java.util.function.IntPredicate;

public class RoundRobinLoadBalancer extends BaseLoadBalancer {

    private Integer lastIdx = -1;

    public RoundRobinLoadBalancer(Long checkAliveInterval, Long aliveTimeout) {
        super(checkAliveInterval, aliveTimeout);
    }

    private AppServer getServer(String url) {
        // Sanity check
        if (appServers.isEmpty()) {
            throw new AppServerNotFoundException("Load Balancer has no registered appServers!");
        }

        // Get next appServer in Round Robin sequence
        Integer count = appServers.size();
        Integer iterationIdx = lastIdx + 1;

        // Helper function to identify if the appServer at a certain iteration is alive
        IntPredicate isAppServerAtIterationAlive = i -> {
            AppServer appServer = appServers.get(i % count);
            boolean isAlive = alivePings.get(appServer) >= 0 && appServer.getCurrentLoad() < 1.0;

            if (url == null)
                return isAlive;
            else
                return isAlive && appServer.getUrls().contains(url);
        };

        // Loop through appServers until we find one that is available and not overloaded
        while (!isAppServerAtIterationAlive.test(iterationIdx)) {

            // If we have made an entire loop around all appServers and none of them are alive, throw
            // an exception
            if (iterationIdx % count == lastIdx || lastIdx == -1 && iterationIdx.equals(count)) {
                throw new MaxLoadException("All appServers are down!");
            }

            // Current appServer is not alive, skip it and move on to the next on
            iterationIdx = iterationIdx + 1;
        }

        // Send request to the appServer and update last appServer index
        lastIdx = iterationIdx % count;
        return appServers.get(lastIdx);
    }

    private AppServer getServer() {
        return getServer(null);
    }

    @Override
    public String routeToEAS(String url, MockRequest request) {
        return getServer(url).callEngine(url, request);
    }

    @Override
    public String get() throws MaxLoadException {
        return getServer().get();
    }

    @Override
    public void registerAppServers(List<AppServer> appServers) {
        super.registerAppServers(appServers);

        // Reset the index to start over the iteration on appServers
        lastIdx = -1;
    }
}
