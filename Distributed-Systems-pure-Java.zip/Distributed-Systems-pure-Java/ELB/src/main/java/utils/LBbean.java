package utils;

import protocol.LoadBalancer;

public class LBbean {

    volatile private static LBbean instance = null;
    private LoadBalancer lb;

    private LBbean() {
    }

    public static LBbean getInstance() {

        if (instance != null) {

        } else {
            synchronized (LBbean.class) {
                if (instance == null) {
                    instance = new LBbean();
                }
            }
        }
        return instance;
    }

    public synchronized void setLoadBalancer(LoadBalancer lb) {
        if (this.lb != null)
            return;
        this.lb = lb;
    }

    public LoadBalancer getLB() {
        return lb;
    }
}
