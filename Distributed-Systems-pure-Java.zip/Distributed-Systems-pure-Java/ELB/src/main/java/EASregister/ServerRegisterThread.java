package EASregister;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import propmodel.Server;
import propmodel.ServerInfo;
import propmodel.ServerList;
import protocol.AppServer;
import protocol.LoadBalancer;
import protocol.ServerContainer;
import servers.SimpleAppServer;
import utils.EAScontainerBean;
import utils.LBbean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.logging.Logger;

public class ServerRegisterThread extends Thread {

    private static Logger logger = Logger.getGlobal();

    Path dataFile = Paths.get(this.getClass().getClassLoader().getResource("eas-elb-data-interaction-file").getFile());
    FileTime ft = FileTime.from(Instant.now());

    @Override
    public void run() {

        while (true) {
            BasicFileAttributes attrs = null;
            try {
                attrs = Files.readAttributes(dataFile, BasicFileAttributes.class);
                if (attrs.lastModifiedTime().equals(ft))
                    sleep(5000l);
                else {
                    updateServerList();
                    ft = attrs.lastModifiedTime();
                }
            } catch (NoSuchFileException e) {
                e.printStackTrace();
                logger.warning("change datafile location to System.getProperty(\"user.home\")+\"/eas-elb-data-interaction-file\"");
                dataFile = new File(System.getProperty("user.home") + "/eas-elb-data-interaction-file").toPath();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateServerList() {

        try {
            RandomAccessFile file = new RandomAccessFile(dataFile.toFile(), "rw");
            FileChannel channel = file.getChannel();
            FileLock lock = null;
            while (lock == null) {
                sleep(500);
                lock = channel.tryLock();
            }
            try {
                ServerList serverList = new Yaml(new Constructor(ServerList.class)).load(Channels.newInputStream(channel));

                if (serverList == null || serverList.getServers() == null)
                    return;

                LoadBalancer loadBalancer = LBbean.getInstance().getLB();
                ServerContainer container = EAScontainerBean.getInstance().getContainer();
                for (ServerInfo serverInfo : serverList.getServers()) {
                    Server server = serverInfo.getServer();

                    String id = server.getId();
                    int port = server.getPort();
                    String serverStatus = server.getServerStatus();

                    if (loadBalancer.getAppServers().stream().anyMatch(appServer -> appServer.getServerId().equals(id) || appServer.getPort() == port)) {
                        if (serverStatus == null || serverStatus.equals("add"))
                            logger.warning("Server ID or port is already registered, skip adding: " + id + ", " + port);
                        else if (serverStatus.equals("shutdown")) {
                            loadBalancer.removeAppServer(loadBalancer.getAppServers().stream().filter(server1 -> server1.getServerId().equals(id)).findAny().get());
                            container.shutdownServer(id);
                            return;
                        }
                    }

                    AppServer appServer = null;
                    if (server.getClazz() == null)
                        appServer = new SimpleAppServer(id, port);
                    else {
                        //Perhaps we're able to customize new server type, but now I've no idea what the requirement would be...
                    }

                    if (appServer != null)
                        loadBalancer.addAppServer(appServer);

                }

                container.setServerList(loadBalancer.getAppServers());
            } finally {
                lock.release();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
