package starter;

import EASregister.ServerRegisterThread;
import balancers.RandomLoadBalancer;
import balancers.RoundRobinLoadBalancer;
import org.yaml.snakeyaml.Yaml;
import protocol.LoadBalancer;
import utils.LBbean;

import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StartELB {

    Set<String> ruleset = new HashSet<>(Arrays.asList("round", "random", "custom"));

    public LBbean start() throws Exception {

        Yaml yaml = new Yaml();
        InputStream inputStream = this.getClass()
                .getClassLoader()
                .getResourceAsStream("elb-configure.yml");
        Map<String, Map<String, String>> ymlmap = yaml.load(inputStream);

        String rule;
        if (!ymlmap.isEmpty() && ymlmap.containsKey("elb") && ymlmap.get("elb").containsKey("rule"))
            rule = ymlmap.get("elb").get("rule");
        else throw new Exception("ELB rule is not defined!");

        if (ruleset.contains(rule)) {
            switch (rule) {
                case "round":
                    LBbean.getInstance().setLoadBalancer(new RoundRobinLoadBalancer(2000l, 1000l));
                    break;
                case "random":
                    LBbean.getInstance().setLoadBalancer(new RandomLoadBalancer(2000l, 1000l));
                    break;
                case "custom":
                    String clazz = ymlmap.get("elb").get("clazz");
                    if (clazz != null)
                        LBbean.getInstance().setLoadBalancer(
                                (LoadBalancer) Class.forName(clazz).getConstructor(Long.class, Long.class).newInstance(new Object[]{2000l, 1000l}));
                    else
                        throw new Exception("Customized ELB class is not correctly defined");
                    break;
            }
        } else
            throw new Exception("ELB rule is not correctly defined - current value is " + rule);

        new ServerRegisterThread().start();

        return LBbean.getInstance();
    }

}
