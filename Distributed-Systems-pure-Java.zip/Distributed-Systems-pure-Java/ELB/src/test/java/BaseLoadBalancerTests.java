import error.AppServerNotFoundException;
import error.MaxLoadException;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import protocol.AppServer;
import protocol.LoadBalancer;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class BaseLoadBalancerTests {

    @Test
    public void testAppServersAllAlive() {
        List<String> appServerNames = Utils.getDummyAppServerNames(5);
        LoadBalancer loadBalancer = Utils.createRoundRobinLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createCheckCountAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        Integer x = 2;
        System.out.println(MessageFormat.format(
                "Wait until Load Balancer will check alive appServers at least {0} times for each appServer",
                x));

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> appServers.stream().allMatch(
                        appServer -> ((Utils.CheckCountAppServer) appServer).getCheckCount() >= x)));
        // @formatter:on
    }

    @ParameterizedTest
    @CsvSource({"5,2", "4,4", "3,0"})
    public void testAppServersUnavailable(Integer appServerCount, Integer appServersDown) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        Utils.AliveAppServersLoadBalancer loadBalancer = Utils.createAliveAppServersLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream().map(Utils::createCheckCountAppServer)
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out
                .println("Wait until Load Balancer will check alive appServers for the first time");

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> appServers.stream().allMatch(
                        appServer -> ((Utils.CheckCountAppServer) appServer).getCheckCount() > 0)));
        // @formatter:on

        System.out.println(MessageFormat.format("Kill first {0} appServers", appServersDown));

        for (int i = 0; i < appServersDown; i++) {
            appServers.get(i).setAvailability(false);
        }

        System.out.println(MessageFormat.format(
                "Check that the number of alive appServers decreased by {0}", appServersDown));

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> loadBalancer.getAliveAppServers().size() == appServers.size() - appServersDown));
        // @formatter:on
    }

    @ParameterizedTest
    @CsvSource({"5,2,3", "10,4,10", "5,5,5", "4,0,8"})
    public void testAppServersRecover(Integer appServerCount, Integer appServersDown,
                                      Integer requestsPerAppServer) {

        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        Utils.AliveAppServersLoadBalancer loadBalancer = Utils.createAliveAppServersLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream()
                .map((name) -> Utils.createCheckCountAppServer(name, requestsPerAppServer * 2))
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out
                .println("Wait until Load Balancer will check alive appServers for the first time");

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> appServers.stream().allMatch(
                        appServer -> ((Utils.CheckCountAppServer) appServer).getCheckCount() > 0)));
        // @formatter:on

        System.out.println(MessageFormat.format("Kill first {0} appServers", appServersDown));

        for (int i = 0; i < appServersDown; i++) {
            appServers.get(i).setAvailability(false);
        }

        System.out.println(MessageFormat.format(
                "Check that the number of alive appServers decreased by {0}", appServersDown));

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> loadBalancer.getAliveAppServers().size() == appServers.size() - appServersDown));
        // @formatter:on

        System.out.println(MessageFormat.format(
                "Check that all requests to load balancer will not be forwarded to the first {0} appServers",
                appServersDown));

        Map<String, Integer> responses = new HashMap<>();

        if (appServerCount.equals(appServersDown)) {
            System.out.println(
                    "All appServers are down, check a request to load balancer will raise an exception");
            assertThrows(MaxLoadException.class, loadBalancer::get);
        } else {
            for (int i = 0; i < (appServerCount - appServersDown) * requestsPerAppServer; i++) {
                assertDoesNotThrow(() -> {
                    String uuid = loadBalancer.get();
                    responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
                });
            }
        }

        for (int i = 0; i < appServerNames.size(); i++) {
            String appServerName = appServerNames.get(i);
            Integer expectedCount = i < appServersDown ? 0 : requestsPerAppServer;
            assertEquals(responses.getOrDefault(appServerName, 0), expectedCount);
        }

        System.out.println(MessageFormat.format("Recover the first two appServers", appServersDown));

        for (int i = 0; i < appServersDown; i++) {
            appServers.get(i).setAvailability(true);
        }

        System.out.println("Check that all appServers are alive");

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> loadBalancer.getAliveAppServers().size() == appServers.size()));
        // @formatter:on

        System.out
                .println("Check that requests to load balancer will be forwarded to all appServers");

        responses.clear();

        for (int i = 0; i < appServerCount * requestsPerAppServer; i++) {
            assertDoesNotThrow(() -> {
                String uuid = loadBalancer.get();
                responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
            });
        }

        for (int i = 0; i < appServerNames.size(); i++) {
            String appServerName = appServerNames.get(i);
            assertEquals(responses.get(appServerName), requestsPerAppServer);
        }
    }

    @ParameterizedTest
    @CsvSource({"4,2,3", "5,1,2", "3,0,5"})
    void testAppServersAdd(Integer appServerCount, Integer newAppServers,
                           Integer requestsPerAppServer) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        Utils.AliveAppServersLoadBalancer loadBalancer = Utils.createAliveAppServersLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream()
                .map((name) -> Utils.createCheckCountAppServer(name, requestsPerAppServer))
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out
                .println("Wait until Load Balancer will check alive appServers for the first time");

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> appServers.stream().allMatch(
                        appServer -> ((Utils.CheckCountAppServer) appServer).getCheckCount() > 0)));
        // @formatter:on

        System.out.println(MessageFormat.format("Add {0} new appServers", newAppServers));

        List<String> newAppServerNames = Utils.getDummyAppServerNames(newAppServers, appServerCount);

        for (String newAppServerName : newAppServerNames) {
            loadBalancer.addAppServer(Utils.createCheckCountAppServer(newAppServerName));
        }

        System.out.println(MessageFormat
                .format("Check that the number of appServers increased by {0}", newAppServers));

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> loadBalancer.getAliveAppServers().size() == appServerCount + newAppServers));
        // @formatter:on

        System.out.println(MessageFormat.format(
                "Check that all requests to load balancer will be forwarded to all {0} appServers",
                appServerCount + newAppServers));

        Map<String, Integer> responses = new HashMap<>();
        List<String> allAppServerNames =
                Stream.concat(appServerNames.stream(), newAppServerNames.stream())
                        .collect(Collectors.toList());

        for (int i = 0; i < allAppServerNames.size() * requestsPerAppServer; i++) {
            assertDoesNotThrow(() -> {
                String uuid = loadBalancer.get();
                responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
            });
        }

        for (String appServerName : allAppServerNames) {
            assertEquals(responses.getOrDefault(appServerName, 0), requestsPerAppServer);
        }
    }

    @ParameterizedTest
    @CsvSource({"5,2,3", "4,3,10", "3,0,5", "6,6,7"})
    void testAppServersRemove(Integer appServerCount, Integer appServersToRemove,
                              Integer requestsPerAppServer) {
        List<String> appServerNames = Utils.getDummyAppServerNames(appServerCount);
        Utils.AliveAppServersLoadBalancer loadBalancer = Utils.createAliveAppServersLoadBalancer();

        // Create appServers and register them on the load balancer
        List<AppServer> appServers = appServerNames.stream()
                .map((name) -> Utils.createCheckCountAppServer(name, requestsPerAppServer + 1))
                .collect(Collectors.toList());
        loadBalancer.registerAppServers(appServers);

        System.out
                .println("Wait until Load Balancer will check alive appServers for the first time");

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> appServers.stream().allMatch(
                        appServer -> ((Utils.CheckCountAppServer) appServer).getCheckCount() > 0)));
        // @formatter:on

        System.out.println(MessageFormat
                .format("Send {0} requests to update the appServer index to point to the last one "
                        + "(in case of Round Robin Load Balancer)", appServerCount));

        Map<String, Integer> responses = new HashMap<>();

        for (int i = 0; i < appServerCount; i++) {
            assertDoesNotThrow(() -> {
                String uuid = loadBalancer.get();
                responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
            });
        }

        for (String appServerName : appServerNames) {
            assertEquals(1, responses.getOrDefault(appServerName, 0));
        }

        System.out.println(MessageFormat.format("Remove last {0} appServers", appServersToRemove));

        for (int i = appServerCount - appServersToRemove; i < appServerCount; i++) {
            loadBalancer.removeAppServer(appServers.get(i));
        }

        List<String> updatedAppServerNames =
                appServerNames.subList(0, appServerCount - appServersToRemove);

        System.out.println(MessageFormat
                .format("Check that the number of appServers decreased by {0}", appServersToRemove));

        // @formatter:off
        assertDoesNotThrow(() -> Awaitility.await()
                .forever()
                .pollInterval(Constants.appServerRequestProcessingTime.dividedBy(2))
                .until(() -> loadBalancer.getAliveAppServers().size() == updatedAppServerNames.size()));
        // @formatter:on

        if (updatedAppServerNames.isEmpty()) {
            System.out.println(
                    "All appServers removed from load balancer. Check exception thrown when sending a request");
            assertThrows(AppServerNotFoundException.class, loadBalancer::get);
        } else {
            System.out.println(MessageFormat.format(
                    "Check that all requests to load balancer will be forwarded to the updated {0} appServers",
                    updatedAppServerNames.size()));

            responses.clear();

            for (int i = 0; i < updatedAppServerNames.size() * requestsPerAppServer; i++) {
                assertDoesNotThrow(() -> {
                    String uuid = loadBalancer.get();
                    responses.put(uuid, responses.getOrDefault(uuid, 0) + 1);
                });
            }

            for (String appServerName : updatedAppServerNames) {
                assertEquals(responses.getOrDefault(appServerName, 0), requestsPerAppServer);
            }
        }
    }
}
