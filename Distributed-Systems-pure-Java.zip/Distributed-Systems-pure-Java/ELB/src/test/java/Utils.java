import balancers.RandomLoadBalancer;
import balancers.RoundRobinLoadBalancer;
import protocol.AppServer;
import protocol.LoadBalancer;
import servers.SimpleAppServer;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Utils {

    static List<String> getDummyAppServerNames(Integer count) {
        return getDummyAppServerNames(count, 0);
    }

    static List<String> getDummyAppServerNames(Integer count, Integer offset) {
        return IntStream.range(offset, offset + count)
                .mapToObj(idx -> MessageFormat.format("appServer{0}", idx))
                .collect(Collectors.toList());
    }

    static AppServer createSimpleAppServer() {
        return new SimpleAppServer(Constants.appServerMaxConcurrentRequests,
                Constants.appServerRequestProcessingTime, "test", 8888);
    }

    static AppServer createSimpleAppServer(String customUuid) {
        return new SimpleAppServer(customUuid, Constants.appServerMaxConcurrentRequests,
                Constants.appServerRequestProcessingTime, "test", 8888);
    }

    static AppServer createCheckCountAppServer(String customUuid) {
        return createCheckCountAppServer(customUuid, Constants.appServerMaxConcurrentRequests);
    }

    static AppServer createCheckCountAppServer(String customUuid, Integer maxConcurrentRequests) {
        return new CheckCountAppServer(customUuid, maxConcurrentRequests,
                Constants.appServerRequestProcessingTime);
    }

    static LoadBalancer createRandomLoadBalancer() {
        return new RandomLoadBalancer(Constants.loadBalancerAliveInterval.toMillis(),
                Constants.loadBalancerAliveTimeout.toMillis());
    }

    static LoadBalancer createRoundRobinLoadBalancer() {
        return new RoundRobinLoadBalancer(Constants.loadBalancerAliveInterval.toMillis(),
                Constants.loadBalancerAliveTimeout.toMillis());
    }

    static AliveAppServersLoadBalancer createAliveAppServersLoadBalancer() {
        return new AliveAppServersLoadBalancer(Constants.loadBalancerAliveInterval.toMillis(),
                Constants.loadBalancerAliveTimeout.toMillis());
    }

    /**
     * This is a custom appServer that counts the number of times {@link #check()} method was
     * invoked.
     *
     * @implNote For testing purposes only!
     */
    static class CheckCountAppServer extends SimpleAppServer {

        private AtomicInteger checkCount = new AtomicInteger();

        CheckCountAppServer(String customUuid, Integer maxConcurrentRequests,
                            Duration oneRequestProcessingTime) {
            super(customUuid, maxConcurrentRequests, oneRequestProcessingTime, "test", 8888);
        }

        @Override
        public Boolean check() {
            checkCount.incrementAndGet();
            return super.check();
        }

        Integer getCheckCount() {
            return checkCount.get();
        }
    }

    /**
     * This is a custom load balancer (based on {@link RoundRobinLoadBalancer}) that has an
     * additional method that will return all currently alive appServers.
     *
     * @implNote For testing purposes only!
     */
    static class AliveAppServersLoadBalancer extends RoundRobinLoadBalancer {

        AliveAppServersLoadBalancer(Long checkAliveInterval, Long aliveTimeout) {
            super(checkAliveInterval, aliveTimeout);
        }

        List<AppServer> getAliveAppServers() {
            return alivePings.entrySet().stream().filter(entry -> entry.getValue() >= 0)
                    .map(Map.Entry::getKey).collect(Collectors.toList());
        }
    }
}
